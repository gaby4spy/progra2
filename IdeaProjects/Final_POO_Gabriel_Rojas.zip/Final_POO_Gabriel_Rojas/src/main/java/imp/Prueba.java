package imp;

public class Prueba {

    public static void main(String[] args) {

        Bienvenida.mostrar();

        /// sean vehiculos
       /* Flota.agregarVehiculo(new Automovil(1, "Toyota", 20000, 1600, 4));
        Flota.agregarVehiculo(new Automovil(2, "Ford", 35000, 2000, 5));
        Flota.agregarVehiculo(new Automovil(3, "Chevrolet", 15000, 1800, 4));


        Flota.agregarVehiculo(new Camion(4, "Volvo", 85000, 20.5));
        Flota.agregarVehiculo(new Camion(5, "Scania", 92000, 22.0));
        Flota.agregarVehiculo(new Camion(6, "Mercedes-Benz", 78000, 18.75));


        Flota.agregarVehiculo(new Motocicleta(7, "Honda", 12000, 180.0, "4T", "15L"));
        Flota.agregarVehiculo(new Motocicleta(8, "Yamaha", 9500, 160.5, "2T", "12L"));
        Flota.agregarVehiculo(new Motocicleta(9, "Kawasaki", 18000, 190.2, "4T", "17L"));*/


        ///  se prueba que no acepte repetidos

       /* Flota.agregarVehiculo(new Motocicleta(7, "Honda", 12000, 180.0, "4T", "15L"));
        Flota.agregarVehiculo(new Motocicleta(8, "Yamaha", 9500, 160.5, "2T", "12L"));
        Flota.agregarVehiculo(new Motocicleta(9, "Kawasaki", 18000, 190.2, "4T", "17L"));*/

        /// muestra los datos del vehiculo si existe si no existe lo indica con un mensaje
       /* Flota.mostrarDatosSiExiste(2);
        Flota.mostrarDatosSiExiste(2222);
        */

        /// lista los nombres de la marca de la flota
        /*Flota.listarMarcasVehiculos();*/

        /// calcular kilometraje
       /* Flota.calcularKilometrajePorTipo();*/


        /// imprime datos float
        /*Flota.imprimirDatosFlota();*/
    }
}
